void insertionSort(ArrayList <Integer> list){

  for (int outer = 1; outer < list.size(); outer++){

    int position = outer;

    int key = list.get(position);

    

    // Shift larger values to the right

    while (position > 0 && list.get(position � 1) > key){

      list.set(position, list.get(position � 1));

      position--;

    }

    list.set(position,  key);

  }

}
public abstract class Animal{
  public abstract String getSound();    
  public abstract String getType();
}

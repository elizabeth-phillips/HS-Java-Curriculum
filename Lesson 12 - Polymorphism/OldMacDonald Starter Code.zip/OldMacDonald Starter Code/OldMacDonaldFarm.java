public class OldMacDonaldFarm{
	public static void main(String[] args){
		Cow c = new Cow();
		System.out.println( c.getType() + " goes " + c.getSound() );

		  // < your code here >
	}
}

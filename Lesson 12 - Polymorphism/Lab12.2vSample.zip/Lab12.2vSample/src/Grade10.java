// AbstractClass04
// This is the <Grade10> subclass of <CommonHighSchool>. 


public class Grade10 extends CommonHighSchool
{
   public void register()     
   { System.out.println("Register 10TH GRADER"); }  
   
   public void orientation()  
   { System.out.println("Organize 10TH GRADE orientation"); }  
   
   public void fundRaising()  
   { System.out.println("Explain 10TH GRADE fund raising"); }  
   
   public void socialEvents() 
   { System.out.println("Organize 10TH GRADE social events"); }  
   
   public void parking()      
   { System.out.println("10TH GRADE students have no parking lot"); }     
}

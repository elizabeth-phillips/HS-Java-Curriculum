// AbstractClass04
// This is the <HighSchool> interface that will be used for 
// "interface & abstract class" Case Study .


public abstract interface HighSchool
{
	public abstract void information();
	public abstract void test();
	public abstract void emergency();
	public abstract void computeGPA();
   public abstract void progress();
   public abstract void attendance();
   public abstract void dressCode();
   public abstract void residence();  
   public abstract void register();
   public abstract void orientation();
   public abstract void fundRaising();
   public abstract void socialEvents();
   public abstract void parking();
}

// AbstractClass04
// This is the <Grade11> subclass of <CommonHighSchool>. 


public class Grade11 extends CommonHighSchool
{
   public void register()     
   { System.out.println("Register 11TH GRADER"); }  
   
   public void orientation()  
   { System.out.println("Organize 11TH GRADE orientation"); }  
   
   public void fundRaising()  
   { System.out.println("Explain 11TH GRADE fund raising"); }  
   
   public void socialEvents() 
   { System.out.println("Organize 11TH GRADE social events"); }  
   
   public void parking()      
   { System.out.println("Distribute 11TH GRADE parking lot stickers"); }    
}

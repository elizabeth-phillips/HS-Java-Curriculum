// AbstractClass04
// This is the <Grade12> subclass of <CommonHighSchool>. 


public class Grade12 extends CommonHighSchool
{
   public void register()     
   { System.out.println("Register 12TH GRADER"); }  
   
   public void orientation()  
   { System.out.println("Organize 12TH GRADE orientation"); }  
   
   public void fundRaising()  
   { System.out.println("Explain 12TH GRADE fund raising"); }  
   
   public void socialEvents() 
   { System.out.println("Organize 12TH GRADE social events"); }  
   
   public void parking()      
   { System.out.println("Distribute 12TH GRADE parking lot stickers"); }     
}
